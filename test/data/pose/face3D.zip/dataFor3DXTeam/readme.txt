format of cam file:
cam pos
cam front
cam up
cam right
